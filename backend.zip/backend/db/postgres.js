const { Pool } = require('pg');

const pool = new Pool({
  host: process.env.POSTGRES_HOST,
  port: process.env.POSTGRES_PORT,
  database: process.env.POSTGRES_DB,
  user: process.env.POSTGRES_USER,
  password: process.env.POSTGRES_PASSWORD
});

pool.query('SELECT NOW()')
  .then(res => console.log('💾 PostgreSQL Connected at:', res.rows[0].now))
  .catch(err => console.error('❌ DB Connection Error:', err));

module.exports = {
  query: (text, params) => pool.query(text, params),
};